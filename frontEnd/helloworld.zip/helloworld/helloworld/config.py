# -*- coding: utf-8 -*-


MONGO_URL = 'mongodb://spider:spider@localhost:27017/spider'

